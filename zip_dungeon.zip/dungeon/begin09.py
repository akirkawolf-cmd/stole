a = float(input())
b = float(input())

result = (a * b) ** 0.5
print(result)