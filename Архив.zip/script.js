const initialChickens = [];

if (!localStorage.getItem('chickenPosts')) {
    localStorage.setItem('chickenPosts', JSON.stringify(initialChickens));
}
if (!localStorage.getItem('users')) {
    localStorage.setItem('users', JSON.stringify([]));
}

const chickenGrid = document.getElementById('chickenGrid');
const searchInput = document.getElementById('searchInput');
const filterButtons = document.querySelectorAll('.filter-btn');
const noResultsBlock = document.getElementById('noResults');
const mainContentBlock = document.querySelector('main.main-content');
const mainPageContent = document.getElementById('mainPageContent');

const authHeaderBlock = document.getElementById('authHeaderBlock');
const authModal = document.getElementById('authModal');
const authForm = document.getElementById('authForm');
const modalTitle = document.getElementById('modalTitle');
const authSubmitBtn = document.getElementById('authSubmitBtn');
const toggleAuthMode = document.getElementById('toggleAuthMode');
const authLoginInput = document.getElementById('authLogin');
const authEmailInput = document.getElementById('authEmail');
const authPasswordInput = document.getElementById('authPassword');
const closeAuthBtn = document.getElementById('closeAuthBtn');

const addPostPanel = document.getElementById('addPostPanel');
const addPostForm = document.getElementById('addPostForm');
const closePostPanelBtn = document.getElementById('closePostPanelBtn');

const fullPostView = document.getElementById('fullPostView');
const backFromFullViewBtn = document.getElementById('backFromFullViewBtn');
const fullViewImg = document.getElementById('fullViewImg');
const fullViewTag = document.getElementById('fullViewTag');
const fullViewTitle = document.getElementById('fullViewTitle');
const fullViewDesc = document.getElementById('fullViewDesc');
const fullViewAuthor = document.getElementById('fullViewAuthor');

let currentCategory = 'all';
let searchQuery = '';
let isSignUpMode = false; 
let currentUser = localStorage.getItem('currentUser') || null;
let previousScreenWasAccount = false;

function renderCards() {
    chickenGrid.innerHTML = '';
    const posts = JSON.parse(localStorage.getItem('chickenPosts')) || [];
    let visibleCardsCount = 0;

    const isAccountPage = addPostPanel.style.display === 'block';

    posts.forEach(post => {
        if (isAccountPage && post.author !== currentUser) return;

        let matchesSearch = isAccountPage 
            ? post.title.toLowerCase().includes(searchQuery)
            : post.title.toLowerCase().includes(searchQuery) || post.author.toLowerCase().includes(searchQuery);

        const matchesCategory = currentCategory === 'all' || post.category === currentCategory;

        if (matchesSearch && matchesCategory) {
            visibleCardsCount++;
            const card = document.createElement('div');
            card.className = 'chicken-card';
            card.style.cursor = 'pointer';
            card.setAttribute('data-category', post.category);

            const showDeleteButton = isAccountPage && currentUser && post.author === currentUser;

            card.innerHTML = `
                <!-- Кнопка удаления появится, только на странице аккаунта -->
                ${showDeleteButton ? `<button class="delete-btn" title="Удалить пост">&times;</button>` : ''}
                
                <div class="image-container">
                    <img src="${post.img}" alt="${post.title}">
                </div>
                <div class="card-info">
                    <span class="tag">${post.category}</span>
                    <h3>${post.title}</h3>
                    <p>${post.desc}</p>
                    <p class="author">Автор: <span>${post.author}</span></p>
                </div>
            `;

            if (showDeleteButton) {
                const deleteBtn = card.querySelector('.delete-btn');
                deleteBtn.addEventListener('click', (e) => {

                    e.stopPropagation(); 
                    
                    const confirmDelete = confirm('Вы уверены, что хотите удалить этот пост? Он также исчезнет с главной страницы.');
                    if (confirmDelete) {

                        let allPosts = JSON.parse(localStorage.getItem('chickenPosts')) || [];

                        allPosts = allPosts.filter(p => p.id !== post.id);

                        localStorage.setItem('chickenPosts', JSON.stringify(allPosts));

                        renderCards();
                    }
                });
            }

            card.addEventListener('click', () => {
                openFullView(post, isAccountPage);
            });

            chickenGrid.appendChild(card);
        }
    });

    noResultsBlock.style.display = visibleCardsCount === 0 ? 'block' : 'none';
}

function openFullView(post, isAccountPage) {
    previousScreenWasAccount = isAccountPage;

    addPostPanel.style.display = 'none';
    mainPageContent.style.display = 'none';

    fullViewImg.src = post.img;
    fullViewImg.alt = post.title;
    fullViewTag.textContent = post.category;
    fullViewTitle.textContent = post.title;
    fullViewDesc.textContent = post.desc;
    fullViewAuthor.textContent = post.author;

    fullPostView.style.display = 'block';
    window.scrollTo(0, 0);
}

backFromFullViewBtn.addEventListener('click', () => {
    fullPostView.style.display = 'none';
    mainPageContent.style.display = 'block';

    if (previousScreenWasAccount) {
        addPostPanel.style.display = 'block';
        searchInput.placeholder = "Поиск по названию...";
    } else {
        addPostPanel.style.display = 'none';
        searchInput.placeholder = "Поиск по названию или автору...";
    }
    renderCards();
});

function updateAuthUI() {
    if (currentUser) {
        authHeaderBlock.innerHTML = `
            <button id="goToAccountBtn" class="filter-btn" style="background: #fff3e0; color: #e65100; font-weight: bold; border: 1px solid #f5c797;">Мой аккаунт: ${currentUser}</button>
            <button id="logoutBtn" class="logout-btn">Выйти</button>
        `;
        
        addPostPanel.style.display = 'block'; 
        searchInput.placeholder = "Поиск по названию...";
        renderCards();

        document.getElementById('goToAccountBtn').addEventListener('click', () => {
            fullPostView.style.display = 'none';
            mainContentBlock.style.display = 'block';
            addPostPanel.style.display = 'block';
            searchInput.placeholder = "Поиск по названию...";
            renderCards();
        });

        document.getElementById('logoutBtn').addEventListener('click', () => {
            localStorage.removeItem('currentUser');
            currentUser = null;
            fullPostView.style.display = 'none';
            mainContentBlock.style.display = 'block';
            addPostPanel.style.display = 'none';
            searchInput.placeholder = "Поиск по названию или автору...";
            updateAuthUI();
            renderCards();
        });
    } else {
        authHeaderBlock.innerHTML = `<button id="openAuthBtn" class="filter-btn active">Войти</button>`;
        addPostPanel.style.display = 'none'; 
        searchInput.placeholder = "Поиск по названию или автору...";
        document.getElementById('openAuthBtn').addEventListener('click', openModal);
    }
}

closePostPanelBtn.addEventListener('click', () => {
    addPostPanel.style.display = 'none';
    searchInput.placeholder = "Поиск по названию или автору...";
    renderCards(); 
});

function openModal() {
    authModal.style.display = 'flex';
    isSignUpMode = false;
    switchAuthMode();
}

function closeModal() {
    authModal.style.display = 'none';
    authForm.reset();
}

function switchAuthMode() {
    if (isSignUpMode) {
        modalTitle.textContent = "Регистрация";
        authSubmitBtn.textContent = "Зарегистрироваться";
        toggleAuthMode.textContent = "Уже есть аккаунт? Войти";
    } else {
        modalTitle.textContent = "Вход в клуб";
        authSubmitBtn.textContent = "Войти";
        toggleAuthMode.textContent = "Нет аккаунта? Зарегистрироваться";
    }
}

authForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const login = authLoginInput.value.trim();
    const email = authEmailInput.value.trim();
    const password = authPasswordInput.value.trim();

    let users = JSON.parse(localStorage.getItem('users')) || [];

    if (isSignUpMode) {

        if (!email.includes('@')) {
            alert('Ошибка: Неверный формат почты! Адрес должен содержать символ "@".');
            return;
        }

        const userExists = users.some(user => user.login.toLowerCase() === login.toLowerCase());
        if (userExists) {
            alert('Пользователь с таким логином уже существует!');
            return;
        }

        users.push({ login, password, email });
        localStorage.setItem('users', JSON.stringify(users));
        alert('Регистрация успешна! Теперь вы можете войти.');
        isSignUpMode = false;
        switchAuthMode();
        authForm.reset();
    } else {
        const user = users.find(user => user.login === login && user.password === password);
        if (user) {
            currentUser = user.login;
            localStorage.setItem('currentUser', currentUser);
            updateAuthUI();
            closeModal();
        } else {
            alert('Неверный логин или пароль!');
        }
    }
});

toggleAuthMode.addEventListener('click', () => {
    isSignUpMode = !isSignUpMode;
    switchAuthMode();
});

closeAuthBtn.addEventListener('click', closeModal);

addPostForm.addEventListener('submit', (e) => {
    e.preventDefault();
    if (!currentUser) return alert('Нужно войти в систему!');

    const title = document.getElementById('postTitle').value.trim();
    const img = document.getElementById('postImg').value.trim();
    const desc = document.getElementById('postDesc').value.trim();
    const category = document.getElementById('postCategory').value;

    const posts = JSON.parse(localStorage.getItem('chickenPosts'));

    posts.unshift({ id: Date.now(), title, author: currentUser, category, img, desc });
    localStorage.setItem('chickenPosts', JSON.stringify(posts));

    addPostForm.reset();
    renderCards(); 
});

searchInput.addEventListener('input', (e) => {
    searchQuery = e.target.value.toLowerCase();
    renderCards();
});

filterButtons.forEach(button => {
    button.addEventListener('click', () => {
        filterButtons.forEach(btn => btn.classList.remove('active'));
        button.classList.add('active');
        currentCategory = button.getAttribute('data-category');
        renderCards();
    });
});

chickenGrid.addEventListener('click', (e) => {

    const deleteBtn = e.target.closest('.delete-btn');
    
    if (deleteBtn) {

        e.stopPropagation();

        const postIdToDelete = Number(deleteBtn.dataset.id);

        const confirmDelete = confirm('Вы уверены, что хотите удалить этот пост? Действие нельзя отменить.');
        
        if (confirmDelete) {

            let posts = JSON.parse(localStorage.getItem('chickenPosts')) || [];

            posts = posts.filter(post => post.id !== postIdToDelete);

            localStorage.setItem('chickenPosts', JSON.stringify(posts));

            renderCards(); 
        }
    }
});

updateAuthUI();
renderCards();
